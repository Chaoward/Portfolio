package HW2.servlet;

import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import HW2.Patient;
import lab9.Vaccine;


@WebServlet("/NewPatient")
public class NewPatient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public NewPatient() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("NewPatient.jsp").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HashMap<String, Patient> patList = (HashMap<String, Patient>) getServletContext().getAttribute("patList");
		HashMap<String, Vaccine> vacList = (HashMap<String, Vaccine>) getServletContext().getAttribute("vacList");
		
		//record date
		Calendar curDate = Calendar.getInstance();
		String dateStr = (curDate.get(Calendar.MONTH) + 1) + "/" + curDate.get(Calendar.DAY_OF_MONTH) + "/" + curDate.get(Calendar.YEAR);
		
		//add new patient to the list
		Patient newPat = new Patient(request.getParameter("name"), vacList.get(request.getParameter("vaccine")), dateStr);
		patList.put(Patient.generateId(patList), newPat);
		
		//subtract a dose
		newPat.getVaccine().totalLeft -= 1;
		
		//redirect to PatientList
		response.sendRedirect("PatientList");
	}

}
