package lab9.servlet;

import java.io.IOException;
import lab9.Vaccine;
import java.util.HashMap;

import java.util.Enumeration;
import java.util.Random;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/VaccineList")
public class VaccineList extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public VaccineList() {
        super();
    }
        
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String html = new String("");
		//ServletContext context = getServletContext();
		response.setContentType("text/html");
		
		request.getRequestDispatcher("/VaccineList.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
