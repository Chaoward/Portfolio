package HW2;

import lab9.Vaccine;

import java.util.HashMap;
import java.util.Random;

public class Patient {
	String name;
	String[] doseDates;
	Vaccine vaccine;
	
	public Patient(String n, Vaccine vac, String date) {
		this.name = n;
		this.doseDates = new String[2];
		this.doseDates[0] = date;
		this.doseDates[1] = "";
		this.vaccine = vac;
		
	}
	


	public static String generateId(HashMap<String, Patient> idList) {
		Random rand = new Random();
		int id = 1 + rand.nextInt(10000);
		
		while (idList.containsKey(id + ""))
			++id;
		
		return id + "";
	}
	

	//===== Getters & Setters =======================

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String[] getDoseDates() {
		return doseDates;
	}


	public void setDoseDates(String[] doseDates) {
		this.doseDates = doseDates;
	}


	public Vaccine getVaccine() {
		return vaccine;
	}


	public void setVaccine(Vaccine vaccine) {
		this.vaccine = vaccine;
	}
}
