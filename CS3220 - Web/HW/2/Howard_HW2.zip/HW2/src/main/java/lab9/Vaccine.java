package lab9;

import java.util.HashMap;
import java.util.Random;

 

public class Vaccine extends Object {
	public String name;
	public int doses;
	public int daysBtwnDose;
	public int totalReceived;
	public int totalLeft;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDoses() {
		return doses;
	}

	public void setDoses(int doses) {
		this.doses = doses;
	}

	public int getDaysBtwnDose() {
		return daysBtwnDose;
	}

	public void setDaysBtwnDose(int daysBtwnDose) {
		this.daysBtwnDose = daysBtwnDose;
	}

	public int getTotalReceived() {
		return totalReceived;
	}

	public void setTotalReceived(int totalReceived) {
		this.totalReceived = totalReceived;
	}

	public int getTotalLeft() {
		return totalLeft;
	}

	public void setTotalLeft(int totalLeft) {
		this.totalLeft = totalLeft;
	}

	public Vaccine(String n, int dose, int days, int r, int l) {
		this.name = n;
		this.doses = dose;
		this.daysBtwnDose = days;
		this.totalReceived = r;
		this.totalLeft = l;
	}
	
	
	public String toString() {
		return this.name + ","
				+ this.doses + ","
				+ this.daysBtwnDose + ","
				+ this.totalReceived + ","
				+ this.totalLeft + "";
	}
	
	public static String genNewId(HashMap<String, Vaccine> vacList) {
    	//HashMap<String, Vaccine> vacList = (HashMap<String, Vaccine>)getServletContext().getAttribute("vacList");
    	Random rand = new Random();
    	int id = 1 + rand.nextInt(100000);
    	
    	//check if id exist in app scope
    	while (vacList.containsKey(id + ""))
    		id++;
    	
    	return id + "";
    }

}
