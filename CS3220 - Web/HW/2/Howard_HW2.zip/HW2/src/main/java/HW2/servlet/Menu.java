package HW2.servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lab9.Vaccine;
import HW2.Patient;


@WebServlet(urlPatterns="/Menu", loadOnStartup=1)
public class Menu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Menu() {
        super();
    }
    
    public void init(ServletConfig config) throws ServletException {
    	super.init(config);
    	ServletContext context = getServletContext();
    	String vacId1, vacId2;
    	
    	//Vaccine init
    	HashMap<String, Vaccine> vacList = new HashMap<String, Vaccine>();
    	
    	context.setAttribute("vacList", vacList);
    	vacList.put(vacId1 = Vaccine.genNewId(vacList), new Vaccine("Pfizer/BioNTech", 2, 21, 10000, 10000));
    	vacList.put(vacId2 = Vaccine.genNewId(vacList), new Vaccine("Johnson & Johnson", 1, 0, 5000, 5000));
    	context.setAttribute("vacList", vacList);
    	
    	//Patient init
    	HashMap<String, Patient> patList = new HashMap<String, Patient>();
    	
    	context.setAttribute("patList", patList);
    	patList.put(Patient.generateId(patList), new Patient("Johnson", vacList.get(vacId1), "2/2/2023") );
    	patList.put(Patient.generateId(patList), new Patient("Jason", vacList.get(vacId1), "2/3/2023") );
    	patList.put(Patient.generateId(patList), new Patient("Joe", vacList.get(vacId1), "2/21/2023") );
    	patList.put(Patient.generateId(patList), new Patient("Jenny", vacList.get(vacId2), "1/20/2023") );
    	context.setAttribute("patList", patList);
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/Menu.jsp").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
