package HW2.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import HW2.Patient;
import lab9.Vaccine;


@WebServlet("/PatientList")
public class PatientList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public PatientList() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//receive 2nd dose from param
		if (request.getParameter("id") != null) {
			doPost(request, response);
			return;
		}
		
		//display
		request.getRequestDispatcher("PatientList.jsp").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HashMap<String, Patient> patList = (HashMap<String, Patient>)getServletContext().getAttribute("patList");
		Patient patient = patList.get(request.getParameter("id"));
		
		//check id
		if ( patient == null ) {
			response.sendRedirect("PatientList");
			return;
		}
		
		//record date
		Calendar curDate = Calendar.getInstance();
		String dateStr = (curDate.get(Calendar.MONTH) + 1) + "/" + curDate.get(Calendar.DAY_OF_MONTH) + "/" + curDate.get(Calendar.YEAR);
		patient.getDoseDates()[1] = dateStr;
		
		//decrease stock
		//HashMap<String, Vaccine> vacList = (HashMap<String, Vaccine>)getServletContext().getAttribute("vacList");
		patient.getVaccine().totalLeft -= 1;
		
		//redirect back to this servlet (removes param)
		response.sendRedirect("PatientList");
	}

}
