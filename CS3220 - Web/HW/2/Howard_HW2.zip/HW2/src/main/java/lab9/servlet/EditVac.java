package lab9.servlet;

import java.io.IOException;
import java.util.HashMap;
import lab9.Vaccine;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/EditVac")
public class EditVac extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public EditVac() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String html = new String("");
		response.setContentType("text/html");
		/*
		HashMap<String, Vaccine> vacList = (HashMap<String, Vaccine>)getServletContext().getAttribute("vacList");
		Vaccine trgtVac = vacList.get( request.getParameter("vacId") );
		
		html += "<!DOCTYPE html>"
				+ "<html> <head> <title>Edit Vaccine</title> </head>"
				+ "<body> <form action='EditVac' method='post'> <table border='2'>"
				+ "<input type='hidden' name='vacId' value='" + request.getParameter("vacId") + "'>"
				+ "<tr> <th>Name</th> <td> <input type='text' name='name' value='" + trgtVac.name + "'> </td> </tr>"
				+ "<tr> <th>Dose Required</th> <td> <input type='number' name='dose' value='" + trgtVac.doses + "'> </td> </tr>"
				+ "<tr> <th>Days Between Doses</th> <td> <input type='number' name='days' value='" + trgtVac.daysBtwnDose + "'> </td> </tr>"
				+ "<tr> <td colspan='2'> <input type='submit' value='Save'> </td> </tr>"
				+ "</table> </form> </body> </html>";*/
		
		request.getRequestDispatcher("/EditVaccine.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HashMap<String, Vaccine> vacList = (HashMap<String, Vaccine>)getServletContext().getAttribute("vacList");
		Vaccine trgtVac = vacList.get( request.getParameter("vacId") );
		
		trgtVac.name = request.getParameter("name");
		trgtVac.doses = Integer.parseInt(request.getParameter("dose"));
		trgtVac.daysBtwnDose = Integer.parseInt(request.getParameter("days"));
		
		getServletContext().setAttribute(request.getParameter("vacId"), vacList);
		response.sendRedirect("VaccineList");
	}
}
