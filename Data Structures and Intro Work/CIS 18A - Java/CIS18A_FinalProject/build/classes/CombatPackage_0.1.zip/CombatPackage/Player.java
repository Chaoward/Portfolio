package CombatPackage;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

public class Player {
    public ArrayList<Monster> pokeDex;
    
    private int pokeballs;
    private String name;

    //verison: 0.0.1
    Player() {
        pokeDex = new ArrayList();
        pokeballs = 5;
        Scanner input = new Scanner(System.in);
        
        do {
            System.out.print("Enter Player Name: ");
            name = input.next();
        } while (name != null);

        pokeDex.add(0, new Monster("Pikachu", 40));
    }
    
    
    
    public void displayPokemons() {
        System.out.println("\n\n//==== Pokemon Storage =====\\\\");
        for (int i = 0; i < this.pokeDex.size(); ++i) {
            System.out.println(i + ".) " + this.pokeDex.get(i).getName());
        }
    }
    
    

    //===== capture() =====================================
    /* Returns bool depending if the pokemon is captured
       Attempts to capture passed in MonsterObj with a roll
       results varying in MonsterObj's HP. */
    //=====================================================
    public boolean capture(Monster pokemon) {
        if (pokeballs > 0) {
            Random rng = new Random();
            int threshold = (pokemon.getHp() + (int)((float)pokemon.getHp() * 0.1f) );
            --this.pokeballs;

            if ( rng.nextInt(pokemon.getHp()) + 1 >= threshold ) {
                pokemon.recoverHp(1.0f);
                pokeDex.add(pokemon);
                
                return true;
            }
        }
        else {
            System.out.println("You ranout of Pokeballs!");
        }

        return false;
    }
    //=====================================================

}
