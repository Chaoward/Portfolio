package CombatPackage;

import java.util.Random;

//verison: 0.0.2
public class Monster {
 
  private String name;
  private int maxHp;
  private int curHp;
  int n; // holds # for Spot in array
  
  
  public Monster() {
    //Insert file reading to pokemon names  
    //name = 
    
    setRandomMaxHp();
  }
  
  public Monster(String _name, int hp) {
      name = _name;
      maxHp = hp;
      curHp = maxHp;
  }
  
  //System.out.println(111);
  public void setName(String nam) { 
    this.name = nam;
  }

  
  public void setRandomMaxHp() {
    Random power = new Random();
    // Get Random nummber for PowerLevel // (100) limit of 100
    int L = power.nextInt(100);
    // Add 1 so that it cant be 0 
    L = L + 1; 
    // set Powerlevel to new random integer. 
    this.maxHp = L;
    this.curHp = this.maxHp;
  }
  
  public void setHp(int amount) { this.curHp = amount > this.maxHp ? this.maxHp : amount; }
  
  
  
  //Accessors
  public int getMaxHp() { return this.maxHp; }
  public int getHp() { return this.curHp; }
  public String getName() { return this.name; }
 
  
  
  //sets curHp to maxHp if healed over maxHp else add amount to heal
  public void heal(int amount) {
      this.curHp = this.curHp + amount > maxHp ? this.maxHp : this.curHp + amount;
  }
  
  
  //recover Hp by percentage of max Hp
  public void recoverHp(float percent) {
      if (this.curHp < 0) { this.curHp = 0; }
      this.curHp += (int)((float)this.maxHp * percent);
      if (this.curHp > this.maxHp) { this.curHp = this.maxHp; }
  }
  
  
  // HP is subtracted the number passed (Damage)
   public void Dmg(int hit) {
    this.curHp -= hit;
   }

   

}