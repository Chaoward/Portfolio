package CombatPackage;

import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;

//verison: 0.0.3
public class CombatEvent {

    static boolean captured;
    static Random rng = new Random();
    static Scanner input = new Scanner(System.in);

    CombatEvent(Player player, Monster enemyMon) {
        captured = false;
        boolean win = combat(player, enemyMon);

        System.out.println(win ? "VICTORY ACHIEVED!" : "The Pokemon ran away\nGood job");
    }

    //===== combat() ==================================================================
    /* returns a win (true) or lose (false). Main turn-based game-loop is here, and ends
       when the enemy poke is captured. */
    //=================================================================================
    private static Boolean combat(Player player, Monster nmepoke) {
        Monster playerMob = choosePokemon(player.pokeDex);
        
        int dmg = 0;
        int accuracy = 0;
        boolean validChoice = true;

        //combat loop
        while (nmepoke.getHp() > 0 && !captured) {
            System.out.println("What will you do? (enter the number of your choice!)");
            System.out.println("1 Fight \n2 Pokeball \n3 RUN");

            do { //input loop
                validChoice = true;

                switch (input.nextInt()) {
                    case 1: //fight
                        accuracy = rng.nextInt(100) + 1;

                        if (accuracy <= 90 && accuracy > 85) {
                            System.out.println("A Critical Hit!");
                            dmg = (rng.nextInt(15) + 11) * 2;
                            System.out.println("You did " + dmg + " damage!");
                            nmepoke.Dmg(dmg);
                        } else if (accuracy <= 85) {
                            dmg = rng.nextInt(15) + 11;
                            System.out.println("You dealt " + dmg + " damage to the enemy!");
                            nmepoke.Dmg(dmg);
                            if (nmepoke.getHp() <= 0) {
                                System.out.println("YOU WIN!!!!!!!");
                                return false;
                            }
                        } else {
                            System.out.println("The enemy dodged the attack!");
                        }
                        break;

                    case 2: //Using an Item
                        System.out.println("What item do you wish to use? \n<-Back \n 1 Pokeball   2 Potion");
                        switch (input.nextInt()) {
                            case 1: //capture
                                System.out.println("You throw a pokeball!");
                                captured = player.capture(nmepoke);
                                break;

                            case 2: //healing item
                                playerMob.heal(30);
                                
                                //player item iventory function GOES HERE!!!
                                
                                System.out.println("Your " + playerMob.getName() +  " healed 30 hp!");
                                break;
                                
                            case 0:
                            default:
                                validChoice = false;
                        }
                        break;

                    case 3: //RUN!!!
                        if (rng.nextInt(5) + 1 >= 4) {
                            System.out.println("wow you're a coward");
                            return false;
                        } else {
                            System.out.println("You failed to run away, and the enemy gets to attack!");
                        }
                        break;
                        
                    default:
                        System.out.println("I'm sorry, I didn't quite catch that, try again.");
                        validChoice = false;
                }
            } while (!validChoice);

            //Enemy Actions
            if (!captured) {
                accuracy = rng.nextInt(100) + 1;

                if (accuracy <= 80 && accuracy > 75) {
                    System.out.println("A Critical Hit!");
                    dmg = (rng.nextInt(15) + 11) * 2;
                    System.out.println("The enemy did " + dmg + " damage!");
                    playerMob.Dmg(dmg);
                } else if (accuracy <= 75) {
                    dmg = rng.nextInt(15) + 11;
                    System.out.println("You were dealt " + dmg + " damage!");
                    playerMob.Dmg(dmg);
                } else {
                    System.out.println("Your pokemon has dodged the attack!");
                }

                if (playerMob.getHp() <= 0) {
                    System.out.println("wow you lost...");
                    return false;
                }
            }
        }

        return true;
    }
    //==============================================================================
    
    
    

    //===== choosePokemon() ==========================================================
    /* returns Monsters that the user chooses.
    (WIP): might be refactored into Player class. */
    //==============================================================================
    private static Monster choosePokemon(ArrayList<Monster> inven) {
        //display pokemon in inventory
        for (int i = 0; i < inven.size(); ++i) {
            System.out.println(i + ".) " + inven.get(i).getName() + " HP: " + inven.get(i).getHp());
        }

        int choice = input.nextInt();
        while (!(choice >= 0 && choice <= inven.size())) {
            System.out.println("INVALID CHOICE!!!");
        }

        if (inven.get(choice).getHp() <= 0) {
            inven.get(choice).recoverHp(0.3f);
        }
        
        return inven.get(choice);
    }
}
